'use strict';
// IDChat sunucusu: yalnizca sifreli veriyi aktarir. Disk yok, veritabani yok, log yok.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 3000;
const PUB = path.join(__dirname, 'public');
const MAX_CLIENTS = 2000;
const MAX_ROOM = 50;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml',
  '.webmanifest': 'application/manifest+json'
};
const HEAD = {
  'Content-Security-Policy': "default-src 'self'; connect-src 'self' ws: wss:; img-src 'self' data:; style-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Cache-Control': 'no-store',
  'Permissions-Policy': 'geolocation=(), camera=(), microphone=()'
};

const server = http.createServer((req, res) => {
  let p = decodeURIComponent((req.url || '/').split('?')[0]);
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUB, p));
  if (!file.startsWith(PUB + path.sep)) { res.writeHead(403, HEAD); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, HEAD); return res.end('404'); }
    res.writeHead(200, { ...HEAD, 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server, maxPayload: 16384 });
const clients = new Map(); // id -> client
const rooms = new Map();   // roomHash -> Set(id)

const B64 = /^[A-Za-z0-9+/]+={0,2}$/;
const ROOM = /^[0-9a-f]{64}$/;
const ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function newId() {
  let id;
  do {
    id = '';
    for (let i = 0; i < 8; i++) { id += ABC[crypto.randomInt(ABC.length)]; if (i === 3) id += '-'; }
  } while (clients.has(id));
  return id;
}
const send = (ws, o) => { if (ws.readyState === 1) ws.send(JSON.stringify(o)); };
const okCipher = d => typeof d.iv === 'string' && d.iv.length === 16 && B64.test(d.iv) &&
  typeof d.ct === 'string' && d.ct.length > 0 && d.ct.length <= 9000 && B64.test(d.ct);

function leave(c) {
  if (!c.room) return;
  const set = rooms.get(c.room);
  if (set) {
    set.delete(c.id);
    if (!set.size) rooms.delete(c.room);
    else for (const i of set) send(clients.get(i).ws, { t: 'peer-', id: c.id });
  }
  c.room = null;
}

wss.on('connection', ws => {
  if (clients.size >= MAX_CLIENTS) return ws.close();
  const id = newId();
  const c = { id, ws, room: null, pub: null, tok: 10, last: Date.now(), alive: true };
  clients.set(id, c);
  send(ws, { t: 'hello', id });

  ws.on('pong', () => { c.alive = true; });
  ws.on('message', raw => {
    const now = Date.now();
    c.tok = Math.min(10, c.tok + (now - c.last) / 500); c.last = now;
    if (c.tok < 1) return; c.tok--;
    let d; try { d = JSON.parse(raw); } catch { return; }
    if (!d || typeof d !== 'object') return;

    if (d.t === 'join') {
      if (c.room || !ROOM.test(d.room) || typeof d.pub !== 'string' || d.pub.length !== 88 || !B64.test(d.pub)) return;
      const set = rooms.get(d.room) || new Set();
      if (set.size >= MAX_ROOM) return send(ws, { t: 'err', m: 'Oda dolu.' });
      const members = [...set].map(i => ({ id: i, pub: clients.get(i).pub }));
      for (const i of set) send(clients.get(i).ws, { t: 'peer+', id, pub: d.pub });
      set.add(id); rooms.set(d.room, set);
      c.room = d.room; c.pub = d.pub;
      send(ws, { t: 'joined', members });
    } else if (d.t === 'msg' && c.room && okCipher(d)) {
      for (const i of rooms.get(c.room)) if (i !== id) send(clients.get(i).ws, { t: 'msg', from: id, iv: d.iv, ct: d.ct, ts: now });
    } else if (d.t === 'dm' && c.room && okCipher(d) && typeof d.to === 'string') {
      const o = clients.get(d.to);
      if (o && o.room === c.room) send(o.ws, { t: 'dm', from: id, iv: d.iv, ct: d.ct, ts: now });
    }
  });
  ws.on('close', () => { leave(c); clients.delete(id); });
  ws.on('error', () => {});
});

setInterval(() => {
  for (const c of clients.values()) {
    if (!c.alive) { c.ws.terminate(); continue; }
    c.alive = false; c.ws.ping();
  }
}, 30000);

server.listen(PORT, () => console.log('IDChat calisiyor: port ' + PORT));
