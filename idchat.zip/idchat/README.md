# IDChat

Hafif, anonim ve uçtan uca şifreli sohbet sistemi. Hesap yok, veritabanı yok, log yok.

- Her bağlantıda sunucu rastgele bir kimlik verir (ör. `K7F2-QX9M`). Sayfayı yenileyince veya çıkıp girince kimlik değişir.
- Oda: aynı oda anahtarını bilenler aynı odaya girer. Anahtar cihazdan çıkmaz.
- Özel mesaj: odadaki bir kimliğe dokunarak.
- Mobil uyumlu, PWA olarak kurulabilir ve APK'ya dönüştürülebilir.

## Çalıştırma

```bash
npm install
npm start        # http://localhost:3000
```

Tarayıcı şifreleme API'si için HTTPS gerekir (localhost hariç). Yayına alırken Nginx veya Caddy ile TLS ekleyin ve WebSocket'e izin verin.

## Gizlilik modeli

| Konu | Uygulama |
|---|---|
| Oda mesajları | Anahtardan PBKDF2 (150k tur) ile türetilen AES-256-GCM. Sunucu anahtarı hiç görmez. |
| Oda kimliği | Şifreleme anahtarından bağımsız ikinci bir PBKDF2 çıktısı. Sunucu sadece bu özeti görür. |
| Özel mesajlar | Her oturumda üretilen ECDH P-256 anahtar çifti, AES-256-GCM. Özel anahtar cihazdan çıkmaz. |
| Saklama | Sunucu belleğinde sadece bağlantı bilgisi tutulur. Mesaj saklanmaz, log yazılmaz. İstemci tarafında localStorage, çerez, önbellek yok. |
| Korumalar | Sıkı CSP, `no-store`, hız sınırı, 16 KB mesaj sınırı, oda başına 50 kişi, XSS'e karşı yalnızca `textContent`. |

Sınırlar:
- Uzun ve rastgele oda anahtarı kullanın ("Rastgele üret" düğmesi 128 bit üretir). Kısa anahtarlar tahmin edilebilir.
- Sunucu işletenin ağ düzeyinde IP görmesini engellemek için Tor veya VPN arkasında çalıştırın.
- Özel mesajlarda sunucu kötü niyetliyse açık anahtarları değiştirebilir. Bunu yakalamak için sohbet başlığındaki doğrulama kodunu karşı tarafla başka bir kanaldan karşılaştırın.

## APK (Capacitor)

1. Sunucuyu HTTPS ile yayına alın.
2. `public/config.js` içinde `window.IDCHAT_SERVER = 'wss://alanadiniz.com';` satırını açın.
3. Derleyin:

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npx cap sync
npx cap open android      # Android Studio: Build > Build APK
```

Simge için `public/logo.svg` dosyasından 1024x1024 PNG üretip `npx @capacitor/assets generate --android` kullanabilirsiniz.

## Yapı

```
server.js          HTTP + WebSocket sunucusu (tek bağımlılık: ws)
public/            İstemci (HTML, CSS, JS, logo, manifest)
capacitor.config.json
```

## Lisans

MIT
