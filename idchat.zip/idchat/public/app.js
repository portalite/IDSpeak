(() => {
'use strict';
const $ = s => document.querySelector(s);
const enc = new TextEncoder(), dec = new TextDecoder();
const b64 = b => btoa(String.fromCharCode(...new Uint8Array(b)));
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
const WS_URL = window.IDCHAT_SERVER || ((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host);

let ws, me, roomId, roomKey, kp, myPub;
const peers = new Map(), dmKeys = new Map(), threads = new Map([['room', []]]), unread = new Set();
let cur = 'room';

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => {});

// ---- Kripto ----
async function roomMaterial(pass) {
  const base = await crypto.subtle.importKey('raw', enc.encode(pass), 'PBKDF2', false, ['deriveBits', 'deriveKey']);
  const p = salt => ({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 150000, hash: 'SHA-256' });
  const id = hex(await crypto.subtle.deriveBits(p('idchat-room-id'), base, 256));
  const key = await crypto.subtle.deriveKey(p('idchat-room-enc'), base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  return { id, key };
}
async function seal(key, obj) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(obj)));
  return { iv: b64(iv), ct: b64(ct) };
}
async function open(key, iv, ct) {
  return JSON.parse(dec.decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(iv) }, key, unb64(ct))));
}
async function dmKey(id) {
  if (dmKeys.has(id)) return dmKeys.get(id);
  const raw = peers.get(id);
  if (!raw) throw new Error('yok');
  const pub = await crypto.subtle.importKey('raw', unb64(raw), { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const k = await crypto.subtle.deriveKey({ name: 'ECDH', public: pub }, kp.privateKey, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  dmKeys.set(id, k);
  return k;
}
async function safety(id) {
  const [x, y] = [myPub, peers.get(id)].sort();
  const h = hex(await crypto.subtle.digest('SHA-256', enc.encode(x + y))).slice(0, 12).toUpperCase();
  return h.match(/.{4}/g).join(' ');
}

// ---- Arayuz ----
function err(t) { $('#err').textContent = t; }
function line(m) {
  const d = document.createElement('div');
  if (m.sys) { d.className = 'sys'; d.textContent = m.text; return d; }
  d.className = 'm' + (m.from === me ? ' me' : '');
  const by = document.createElement('span'); by.className = 'by'; by.textContent = m.from === me ? 'Sen' : m.from;
  const t = document.createElement('div'); t.textContent = m.text;
  const tm = document.createElement('time'); tm.textContent = new Date(m.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  d.append(by, t, tm);
  return d;
}
function renderLog() {
  const log = $('#log'); log.textContent = '';
  for (const m of threads.get(cur) || []) log.append(line(m));
  log.scrollTop = log.scrollHeight;
}
function renderTabs() {
  const nav = $('#tabs'); nav.textContent = '';
  for (const name of threads.keys()) {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = name === 'room' ? 'Oda' : name;
    if (name === cur) b.className = 'on'; else if (unread.has(name)) b.className = 'unread';
    b.onclick = () => openThread(name);
    nav.append(b);
  }
}
async function renderInfo() {
  const el = $('#info');
  if (cur === 'room') el.textContent = 'Oda: ' + (peers.size + 1) + ' kişi. Uçtan uca şifreli.';
  else if (peers.has(cur)) el.textContent = 'Doğrulama kodu: ' + await safety(cur) + ' (karşı tarafla aynı olmalı)';
  else el.textContent = 'Bu kullanıcı odadan ayrıldı.';
}
function renderMembers() {
  const box = $('#members'); box.textContent = '';
  const p = document.createElement('p');
  p.textContent = peers.size ? 'Özel mesaj için bir kimliğe dokun.' : 'Odada başka kimse yok.';
  box.append(p);
  for (const id of peers.keys()) {
    const b = document.createElement('button'); b.type = 'button'; b.textContent = id;
    b.onclick = () => openThread(id);
    box.append(b);
  }
}
function openThread(name) {
  if (!threads.has(name)) threads.set(name, []);
  cur = name; unread.delete(name);
  $('#members').classList.add('hidden');
  renderTabs(); renderLog(); renderInfo();
}
function add(thread, m) {
  if (!threads.has(thread)) threads.set(thread, []);
  threads.get(thread).push(m);
  if (thread === cur) {
    const log = $('#log'); log.append(line(m)); log.scrollTop = log.scrollHeight;
  } else { unread.add(thread); }
  renderTabs();
}
const sys = text => add('room', { sys: true, text, ts: Date.now() });

// ---- Baglanti ----
async function join() {
  const pass = $('#key').value;
  if (pass.length < 8) return err('Anahtar en az 8 karakter olmalı.');
  err(''); $('#go').disabled = true;
  try {
    const m = await roomMaterial(pass); roomId = m.id; roomKey = m.key;
    kp = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveKey']);
    myPub = b64(await crypto.subtle.exportKey('raw', kp.publicKey));
  } catch { $('#go').disabled = false; return err('Güvenli bağlantı gerekli (HTTPS).'); }
  ws = new WebSocket(WS_URL);
  ws.onerror = () => { $('#go').disabled = false; err('Sunucuya bağlanılamadı.'); };
  ws.onclose = () => {
    if (!$('#chat').classList.contains('hidden')) { $('#info').textContent = 'Bağlantı koptu. Yeni kimlik için çıkıp tekrar girin.'; $('#form').classList.add('hidden'); }
    else $('#go').disabled = false;
  };
  ws.onmessage = ev => { let d; try { d = JSON.parse(ev.data); } catch { return; } onMsg(d); };
}
async function onMsg(d) {
  switch (d.t) {
    case 'hello':
      me = d.id;
      ws.send(JSON.stringify({ t: 'join', room: roomId, pub: myPub }));
      break;
    case 'joined':
      for (const p of d.members) peers.set(p.id, p.pub);
      $('#me').textContent = me;
      $('#join').classList.add('hidden'); $('#chat').classList.remove('hidden');
      sys('Kimliğin: ' + me + '. Bu kimlik sadece bu oturum için geçerli.');
      openThread('room'); renderMembers();
      break;
    case 'peer+':
      peers.set(d.id, d.pub); dmKeys.delete(d.id);
      sys(d.id + ' katıldı.'); renderMembers(); renderInfo();
      break;
    case 'peer-':
      peers.delete(d.id); dmKeys.delete(d.id);
      sys(d.id + ' ayrıldı.'); renderMembers(); renderInfo();
      break;
    case 'msg':
      try { const o = await open(roomKey, d.iv, d.ct); add('room', { from: d.from, text: String(o.m), ts: d.ts }); } catch {}
      break;
    case 'dm':
      try { const o = await open(await dmKey(d.from), d.iv, d.ct); add(d.from, { from: d.from, text: String(o.m), ts: d.ts }); } catch {}
      break;
    case 'err': err(d.m); break;
  }
}
async function submit(e) {
  e.preventDefault();
  const text = $('#msg').value.trim();
  if (!text || !ws || ws.readyState !== 1) return;
  $('#msg').value = '';
  try {
    if (cur === 'room') {
      ws.send(JSON.stringify({ t: 'msg', ...(await seal(roomKey, { m: text })) }));
    } else {
      if (!peers.has(cur)) return add(cur, { sys: true, text: 'Kullanıcı odada değil.', ts: Date.now() });
      ws.send(JSON.stringify({ t: 'dm', to: cur, ...(await seal(await dmKey(cur), { m: text })) }));
    }
    add(cur, { from: me, text, ts: Date.now() });
  } catch {}
}

$('#go').onclick = join;
$('#key').onkeydown = e => { if (e.key === 'Enter') join(); };
$('#gen').onclick = () => {
  const k = $('#key'); k.type = 'text';
  k.value = hex(crypto.getRandomValues(new Uint8Array(16))).match(/.{4}/g).join('-');
};
$('#mem').onclick = () => $('#members').classList.toggle('hidden');
$('#leave').onclick = () => { try { ws.close(); } catch {} location.reload(); };
$('#form').onsubmit = submit;
})();
