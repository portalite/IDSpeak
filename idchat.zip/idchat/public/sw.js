// Onbellek yok: hicbir sey cihazda saklanmaz. Sadece kurulabilirlik icin.
self.addEventListener('fetch', e => e.respondWith(fetch(e.request)));
