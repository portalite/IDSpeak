// APK / ayri sunucu icin: asagidaki satirin yorumunu kaldirip sunucu adresini yazin.
// window.IDCHAT_SERVER = 'wss://sunucu-adresiniz.com';
